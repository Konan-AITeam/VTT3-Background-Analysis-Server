wget ftp://mldisk.sogang.ac.kr/vtt/place/place47/categories.txt -O /workspace/Modules/places/categories.txt
wget ftp://mldisk.sogang.ac.kr/vtt/place/place47/place47-210903.pth.tar -O /workspace/Modules/places/place47.pth.tar
